# ECLIPSE Lock Studio — Premium UI prototype

A Kotlin + Jetpack Compose source project for a polished lock-screen customization editor preview.

## Included
- Live clock preview (updates every second)
- Drag clock to reposition it in the preview
- Animated size and horizontal stretch controls
- Show/hide date and preview hint
- Four dark gradient wallpaper presets
- GitHub Actions workflow to build and upload a debug APK

## Build
Open the project in Android Studio and run `:app:assembleDebug`, or push it to GitHub and run Actions → Build ECLIPSE Lock Studio APK. Download the workflow artifact after it succeeds.

## Important
This is an editor/preview prototype. It does not replace or unlock the secure Huawei system lock screen and does not modify PIN, password, or fingerprint security. Keep Huawei's system lock enabled.

Package: `com.eclipse.lockscreen`
Min Android: 8.0 (API 26)
