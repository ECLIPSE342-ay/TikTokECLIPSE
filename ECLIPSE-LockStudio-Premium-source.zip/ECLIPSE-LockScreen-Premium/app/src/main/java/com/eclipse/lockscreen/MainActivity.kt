package com.eclipse.lockscreen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private val Ink = Color(0xFF080910)
private val Panel = Color(0xFF171925)
private val Violet = Color(0xFFB7A0FF)
private val Muted = Color(0xFF9A9BAC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 9, 16)
        window.navigationBarColor = android.graphics.Color.rgb(8, 9, 16)
        setContent { EclipseStudio() }
    }
}

@Composable
private fun EclipseStudio() {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }

    var clockSize by remember { mutableFloatStateOf(78f) }
    var stretch by remember { mutableFloatStateOf(1.0f) }
    var clockX by remember { mutableFloatStateOf(0f) }
    var clockY by remember { mutableFloatStateOf(0f) }
    var selectedBg by remember { mutableIntStateOf(0) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showDate by remember { mutableStateOf(true) }
    var showHint by remember { mutableStateOf(true) }

    val backgrounds = listOf(
        Brush.linearGradient(listOf(Color(0xFF21143D), Color(0xFF090A12), Color(0xFF090A12))),
        Brush.linearGradient(listOf(Color(0xFF132C3A), Color(0xFF090B13), Color(0xFF090B13))),
        Brush.linearGradient(listOf(Color(0xFF3A182A), Color(0xFF100B16), Color(0xFF080910))),
        Brush.linearGradient(listOf(Color(0xFF252A37), Color(0xFF090A12), Color(0xFF090A12)))
    )
    val dateText = now.format(DateTimeFormatter.ofPattern("EEEE  •  d MMMM"))
    val timeText = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val animatedSize by animateFloatAsState(clockSize, tween(220, easing = FastOutSlowInEasing), label = "size")
    val animatedStretch by animateFloatAsState(stretch, tween(220, easing = FastOutSlowInEasing), label = "stretch")

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Ink)
                .verticalScroll(rememberScrollState())
                .padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF9B7BFF), Color(0xFF44306D)))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("E", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ECLIPSE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Text("LOCK STUDIO", color = Muted, fontSize = 9.sp, letterSpacing = 2.8.sp)
                }
                Surface(color = Color(0xFF211C31), shape = CircleShape) {
                    Text("BETA", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Violet, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }

            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Предпросмотр", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text("LIVE", color = Color(0xFF9DE7C3), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Box(Modifier.padding(start = 6.dp).size(6.dp).background(Color(0xFF69D6A0), CircleShape))
            }
            Spacer(Modifier.height(11.dp))

            Box(
                Modifier.fillMaxWidth().height(430.dp)
                    .shadow(24.dp, RoundedCornerShape(30.dp))
                    .clip(RoundedCornerShape(30.dp))
                    .background(backgrounds[selectedBg])
                    .border(1.dp, Color.White.copy(alpha = .12f), RoundedCornerShape(30.dp))
            ) {
                // Subtle decorative glows
                Box(Modifier.align(Alignment.TopEnd).offset(x = 70.dp, y = (-70).dp).size(210.dp)
                    .background(Color(0xFF9C72FF).copy(alpha = .12f), CircleShape))
                Box(Modifier.align(Alignment.BottomStart).offset(x = (-80).dp, y = 80.dp).size(190.dp)
                    .background(Color(0xFF4B9DCA).copy(alpha = .09f), CircleShape))

                Column(
                    Modifier.align(Alignment.TopCenter).padding(top = 35.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("ECLIPSE EDITION", color = Color.White.copy(alpha = .48f), fontSize = 9.sp, letterSpacing = 3.sp)
                    if (showDate) {
                        Spacer(Modifier.height(9.dp))
                        Text(dateText.uppercase(), color = Color.White.copy(alpha = .76f), fontSize = 10.sp, letterSpacing = 1.4.sp)
                    }
                }

                Text(
                    timeText,
                    Modifier.align(Alignment.Center)
                        .offset { IntOffset(clockX.roundToInt(), clockY.roundToInt()) }
                        .graphicsLayer {
                            scaleX = animatedStretch
                            scaleY = 1f
                        }
                        .pointerInput(Unit) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                clockX += drag.x
                                clockY += drag.y
                            }
                        },
                    color = Color.White,
                    fontSize = animatedSize.sp,
                    fontWeight = FontWeight.ExtraLight,
                    letterSpacing = (-3).sp,
                    lineHeight = (animatedSize * 1.04f).sp,
                    textAlign = TextAlign.Center
                )

                Column(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("•••", color = Color.White.copy(alpha = .55f), fontSize = 18.sp)
                    if (showHint) {
                        Spacer(Modifier.height(5.dp))
                        Text("ПЕРЕТАЩИ ЧАСЫ, ЧТОБЫ ПЕРЕМЕСТИТЬ", color = Color.White.copy(alpha = .42f), fontSize = 8.sp, letterSpacing = 1.2.sp)
                    }
                }
            }

            Spacer(Modifier.height(17.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(5.dp)
            ) {
                StudioTab("Часы", selectedTab == 0, Modifier.weight(1f)) { selectedTab = 0 }
                StudioTab("Вид", selectedTab == 1, Modifier.weight(1f)) { selectedTab = 1 }
                StudioTab("Обои", selectedTab == 2, Modifier.weight(1f)) { selectedTab = 2 }
            }
            Spacer(Modifier.height(14.dp))

            when (selectedTab) {
                0 -> {
                    SettingPanel(title = "Размер часов", value = "${clockSize.roundToInt()} sp") {
                        Slider(value = clockSize, onValueChange = { clockSize = it }, valueRange = 42f..112f)
                    }
                    Spacer(Modifier.height(10.dp))
                    SettingPanel(title = "Растяжение по ширине", value = "${(stretch * 100).roundToInt()}%") {
                        Slider(value = stretch, onValueChange = { stretch = it }, valueRange = .72f..1.42f)
                    }
                    Spacer(Modifier.height(10.dp))
                    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Показывать дату", color = Color.White, fontSize = 13.sp)
                                Text("Над часами в предпросмотре", color = Muted, fontSize = 10.sp)
                            }
                            Switch(checked = showDate, onCheckedChange = { showDate = it })
                        }
                    }
                }
                1 -> {
                    SettingPanel(title = "Положение часов", value = "Перетаскивай на экране") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { clockX = 0f; clockY = 0f }) { Text("По центру") }
                            OutlinedButton(onClick = { clockY -= 18f }) { Text("Выше") }
                            OutlinedButton(onClick = { clockY += 18f }) { Text("Ниже") }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Подсказка на превью", color = Color.White, fontSize = 13.sp)
                                Text("Показывать инструкцию под часами", color = Muted, fontSize = 10.sp)
                            }
                            Switch(checked = showHint, onCheckedChange = { showHint = it })
                        }
                    }
                }
                else -> {
                    Text("Выбери атмосферу", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        backgrounds.indices.forEach { index ->
                            val chosen = selectedBg == index
                            Box(
                                Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(15.dp))
                                    .background(backgrounds[index])
                                    .border(if (chosen) 2.dp else 1.dp, if (chosen) Violet else Color.White.copy(alpha = .12f), RoundedCornerShape(15.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (chosen) Icon(Icons.Rounded.Check, contentDescription = "Выбрано", tint = Color.White)
                                else Text("${index + 1}", color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(7.dp))
                    Text("Нажми на вариант, чтобы применить фон.", color = Muted, fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        backgrounds.indices.forEach { index ->
                            TextButton(onClick = { selectedBg = index }) { Text("Фон ${index + 1}") }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Text(
                "ПРОТОТИП РЕДАКТОРА • НЕ ЗАМЕНЯЕТ СИСТЕМНУЮ БЛОКИРОВКУ HUAWEI",
                color = Color(0xFF777889), fontSize = 8.sp, letterSpacing = 1.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun StudioTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color by animateColorAsState(if (selected) Color(0xFF39304F) else Color.Transparent, label = "tab")
    Surface(
        modifier = modifier.height(42.dp),
        color = color,
        shape = RoundedCornerShape(14.dp),
        onClick = onClick
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(label, color = if (selected) Color.White else Muted, fontSize = 12.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
        }
    }
}

@Composable
private fun SettingPanel(title: String, value: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                Text(value, color = Violet, fontSize = 11.sp)
            }
            content()
        }
    }
}
